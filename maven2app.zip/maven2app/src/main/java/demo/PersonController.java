package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import demo.model.Person;
import demo.repository.PersonRepository;

@RestController
@RequestMapping("/")
public class PersonController {
	 
	@Autowired
	PersonRepository personRepository;
	
	@RequestMapping("/getAllPersons")
	public List<Person> getAll(){
		List<Person> allPersons = (List<Person>) personRepository.findAll();
		
		return allPersons;
	}
	
	@RequestMapping("/create")
	public Person create(Person person){
		person = personRepository.save(person);
		return person;
	}
	
	@RequestMapping("/read")
	public Person read(@RequestParam Long personId) {
		Person person = personRepository.findOne(personId);
		return person;
	}
	
	/**
	  * GET /update  --> Update a booking record and save it in the database.
	  */
	 @RequestMapping("/update/{personId}")
	 public Person update(@PathVariable Long personId, @RequestParam String firstName, @RequestParam String lastName) {
		 Person person = personRepository.findOne(personId);
	  person.setFirstName(firstName);
	  person.setLastName(lastName);
	  
	  person = personRepository.save(person);
	     return person;
	 }
	 
	 /**
	  * GET /delete  --> Delete a booking from the database.
	  */
	 @RequestMapping("/delete")
	 public String delete(@RequestParam Long personId) {
	  personRepository.delete(personId);
	     return "person #"+personId+" deleted successfully";
	 }
	 
	 
	   @RequestMapping("/hello")
	    public String hello(Model model, @RequestParam(value="name", required=false, defaultValue="World") String name) {
	        model.addAttribute("name", name);
	        return "hello";
	    }
}
